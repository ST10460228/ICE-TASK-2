
package surnamelearnertasktwooprj;

public class Learner {
private String fullName;
   private String subject;
   private double assignmentMark;
   private double testMark;
   private double examMark;
   private double calcFinalMark;
   
   // default constraction 
   public Learner (){
       fullName = "";
       subject = "";
       assignmentMark = 0.0;
       testMark = 0.0;
       examMark = 0.0;
   }
   
    // the get and set default values of the attributes 
   
   public void setfullName(String fullNmane){
       this.fullName = fullName;
   }
   public String getfullName(){
       return fullName;
   }
   public void setsubject(String subject){
       this.subject = subject;
   }
   public String getsubject(){
       return subject;
   }
   public void setassignmentMark(double assignmentMark){
       this.assignmentMark = assignmentMark;
   }
   public double getassignmentMark(){
       return assignmentMark; 
   }
   public void settestMark(double testMark){
       this.testMark = testMark;
   }
   public double testMark(){
       return testMark;
   }
   public void setexamMark(double examMark){
       this.examMark = examMark;
   }
   public double getexamMark(){
       return examMark;
   }
   // method to callculate the final mark (average mark)
   public void setcalcFinalMark(){
       this.calcFinalMark = calcFinalMark;
   }
  public double getcalcuFinalMark(){
       return (assignmentMark + testMark + examMark)/3; 
}
}
