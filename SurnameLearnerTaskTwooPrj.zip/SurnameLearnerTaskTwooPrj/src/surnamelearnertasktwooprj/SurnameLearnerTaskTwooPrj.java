
package surnamelearnertasktwooprj;
import javax.swing.JOptionPane;
public class SurnameLearnerTaskTwooPrj {

    public static void main(String[] args) {
       Learner learner = new Learner();

        // Prompt user for input and set values
        learner.setfullName(JOptionPane.showInputDialog("Please Enter full Name"));
        learner.setsubject(JOptionPane.showInputDialog("Please Enter subject"));
        learner.setassignmentMark(Double.parseDouble(JOptionPane.showInputDialog("Please Enter assignmentMark")));
        learner.settestMark(Double.parseDouble(JOptionPane.showInputDialog("Please Enter testMark")));
        learner.setexamMark(Double.parseDouble(JOptionPane.showInputDialog("Please Enter examMark")));

        
         // Calculate and display average mark
        calculateAndDisplayAverage(learner);
        
        // Display final mark
        displayFinalMark(learner);   
    } 
    
    public static void calculateAndDisplayAverage(Learner learner){
        double averageMark = learner.getcalcuFinalMark();
        JOptionPane.showMessageDialog(null,"Average mark: " + averageMark);
    }
  
    public static void displayFinalMark(Learner learner){
        JOptionPane.showMessageDialog(null,"Student full name: " + learner.getfullName()+ 
                "\nSubject: " + learner.getsubject()+ 
                "\nFinal Mark: " + learner.getcalcuFinalMark());
    }
}

